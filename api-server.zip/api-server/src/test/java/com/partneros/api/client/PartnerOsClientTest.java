package com.partneros.api.client;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.partneros.api.dto.auth.AuthTokenRequest;
import com.partneros.api.dto.auth.AuthTokenResponse;
import com.partneros.api.exception.PartnerOsClientException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.RestClient;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.client.ExpectedCount.once;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.content;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withStatus;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;
import static org.springframework.http.HttpStatus.BAD_REQUEST;

class PartnerOsClientTest {

    private MockRestServiceServer server;
    private PartnerOsClient client;

    @BeforeEach
    void setUp() {
        RestClient.Builder builder = RestClient.builder().baseUrl("https://partneros.test");
        server = MockRestServiceServer.bindTo(builder).build();
        client = new PartnerOsClient(builder.build(), new ObjectMapper());
    }

    @Test
    void requestsAndParsesClientCredentialsToken() {
        server.expect(once(), requestTo("https://partneros.test/v1/partneros/auth/token"))
                .andExpect(method(HttpMethod.POST))
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_FORM_URLENCODED))
                .andExpect(content().string(containsString("grant_type=client_credentials")))
                .andExpect(content().string(containsString("client_id=client-1")))
                .andRespond(withSuccess(
                        """
                        {"access_token":"token-value","token_type":"Bearer","expires_in":3600}
                        """,
                        MediaType.APPLICATION_JSON
                ));

        AuthTokenResponse response = client.requestToken(new AuthTokenRequest(
                "client_credentials", "client-1", "secret", null
        ));

        assertThat(response.accessToken()).isEqualTo("token-value");
        assertThat(response.expiresIn()).isEqualTo(3600);
        server.verify();
    }

    @Test
    void mapsPartnerOsErrorBodyToTypedException() {
        server.expect(once(), requestTo("https://partneros.test/v1/partneros/auth/token"))
                .andRespond(withStatus(BAD_REQUEST)
                        .contentType(MediaType.APPLICATION_JSON)
                        .body("{\"errorCode\":\"INVALID_CLIENT\",\"message\":\"Client is not registered\"}"));

        assertThatThrownBy(() -> client.requestToken(new AuthTokenRequest(
                "client_credentials", "bad-client", "secret", null
        )))
                .isInstanceOfSatisfying(PartnerOsClientException.class, exception -> {
                    assertThat(exception.getUpstreamStatus()).isEqualTo(400);
                    assertThat(exception.getUpstreamCode()).isEqualTo("INVALID_CLIENT");
                    assertThat(exception.getMessage()).isEqualTo("Client is not registered");
                });
        server.verify();
    }
}