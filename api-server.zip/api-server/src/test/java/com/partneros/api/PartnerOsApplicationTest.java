package com.partneros.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(
        webEnvironment = SpringBootTest.WebEnvironment.NONE,
        properties = "partneros.persistence.enabled=false"
)
class PartnerOsApplicationTest {

    @Test
    void applicationContextStartsWithoutMongoWhenPersistenceIsDisabled() {
    }
}