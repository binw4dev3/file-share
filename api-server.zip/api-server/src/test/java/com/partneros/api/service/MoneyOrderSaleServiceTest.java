package com.partneros.api.service;

import com.partneros.api.client.PartnerOsClient;
import com.partneros.api.dto.common.PartnerOsRequestHeaders;
import com.partneros.api.dto.sale.ValidateSaleRequest;
import com.partneros.api.dto.sale.ValidateSaleResponse;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class MoneyOrderSaleServiceTest {

    @Test
    void validatesAndPersistsTypedSaleResponse() {
        PartnerOsClient client = mock(PartnerOsClient.class);
        PartnerOsAuthService authService = mock(PartnerOsAuthService.class);
        SalePersistenceService persistenceService = mock(SalePersistenceService.class);
        MoneyOrderSaleService service = new MoneyOrderSaleService(client, authService, persistenceService);

        PartnerOsRequestHeaders headers = new PartnerOsRequestHeaders(
                null, "RMO_V1", "external-1", "USATEST", "RETAIL",
                "idempotency-1", "038042", "OP001", "device-1", null
        );
        ValidateSaleRequest request = mock(ValidateSaleRequest.class);
        ValidateSaleResponse response = new ValidateSaleResponse(
                "0170128310", "2026-09-11 03:08:44", "256968842", null
        );

        when(authService.resolveAuthorization(null)).thenReturn("Bearer access-token");
        when(client.validateSale("Bearer access-token", headers, request)).thenReturn(response);

        ValidateSaleResponse result = service.validateSale(headers, request);

        assertThat(result).isSameAs(response);
        verify(persistenceService).saveValidated(headers, request, response);
    }
}