package com.partneros.api.exception;

public class PartnerOsConfigurationException extends RuntimeException {

    public PartnerOsConfigurationException(String message) {
        super(message);
    }
}