package com.partneros.api.dto.sale;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
public record ValidateSaleRequest(
        String customerUmn,
        @NotNull @Valid Sender sender,
        @NotNull @Valid Transaction transaction
) {
    public record Sender(
            @NotNull @Valid Name name,
            @NotNull @Valid Address address,
            String dateOfBirth,
            @Valid ContactDetails contactDetails,
            @Valid IdDetails idDetails,
            @Valid Demographics demographics
    ) {
    }

    public record Name(
            @NotBlank String firstName,
            @NotBlank String lastName,
            String middleName,
            String secondLastName
    ) {
    }

    public record Address(
            @NotBlank String line1,
            String line2,
            String line3,
            @NotBlank String city,
            String state,
            String stateCode,
            @NotBlank String postalCode,
            @NotBlank String countryCode,
            String country
    ) {
    }

    public record ContactDetails(
            String email,
            @Valid Phone phone,
            @Valid Phone alternatePhone,
            @Valid Phone mobile
    ) {
    }

    public record Phone(String countryCode, String number) {
    }

    public record IdDetails(
            @Valid IdentityDocument primaryId,
            @Valid IdentityDocument secondaryId,
            @Valid IdentityDocument tertiaryId
    ) {
    }

    public record IdentityDocument(
            String type,
            String number,
            String stateOfIssue,
            String issuingAgency,
            String issuingCountry,
            String issuingAuthority,
            String issueDate,
            String doesIdHaveIssueDate,
            String doesIdHaveExpDate,
            String expirationDate
    ) {
    }

    public record Demographics(
            String gender,
            String nationality,
            String occupation,
            String citizenship,
            String cityOfBirth,
            String countryOfBirth,
            String isAResident
    ) {
    }

    public record Transaction(
            String transactionId,
            Boolean actOnOtherBehalf,
            Boolean isTxnOnBehalfOfIndOrOrg,
            Boolean ackFlag,
            String relationship,
            String sourceOfFunds,
            @NotBlank String payIn,
            @NotBlank String orderType,
            @NotNull @Valid Financials financials
    ) {
    }

    public record Financials(
            @NotBlank @Schema(example = "350.00") String sendAmount,
            @NotBlank @Schema(example = "50.00") String totalFee,
            @NotNull @Positive Integer noOfChecks,
            @NotEmpty List<@Valid CheckDetail> checkDetails
    ) {
    }

    public record CheckDetail(
            String serialNumber,
            @NotBlank @Schema(description = "PartnerOS check amount representation", example = "35000") String amount,
            @NotBlank @Schema(description = "PartnerOS fee representation", example = "5000") String fee,
            String seqNumber
    ) {
    }
}