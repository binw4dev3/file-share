package com.partneros.api.config;

import com.mongodb.ConnectionString;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.partneros.api.persistence.MoneyOrderSaleRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

@Configuration
@ConditionalOnProperty(prefix = "partneros.persistence", name = "enabled", havingValue = "true")
@EnableMongoRepositories(basePackageClasses = MoneyOrderSaleRepository.class)
public class MongoPersistenceConfig {

    @Bean(destroyMethod = "close")
    public MongoClient mongoClient(@Value("${spring.data.mongodb.uri}") String uri) {
        return MongoClients.create(uri);
    }

    @Bean
    public MongoTemplate mongoTemplate(
            MongoClient mongoClient,
            @Value("${spring.data.mongodb.uri}") String uri
    ) {
        ConnectionString connectionString = new ConnectionString(uri);
        String database = connectionString.getDatabase();
        if (database == null || database.isBlank()) {
            database = "partneros";
        }
        return new MongoTemplate(mongoClient, database);
    }
}