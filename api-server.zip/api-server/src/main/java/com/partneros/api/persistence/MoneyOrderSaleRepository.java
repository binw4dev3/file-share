package com.partneros.api.persistence;

import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface MoneyOrderSaleRepository extends MongoRepository<MoneyOrderSaleDocument, String> {

    Optional<MoneyOrderSaleDocument> findFirstByExternalRefIdOrderByUpdatedAtDesc(String externalRefId);
}