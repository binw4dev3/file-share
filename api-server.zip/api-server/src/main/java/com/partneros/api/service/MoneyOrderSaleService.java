package com.partneros.api.service;

import com.partneros.api.client.PartnerOsClient;
import com.partneros.api.dto.common.PartnerOsRequestHeaders;
import com.partneros.api.dto.sale.InitiateSaleRequest;
import com.partneros.api.dto.sale.InitiateSaleResponse;
import com.partneros.api.dto.sale.SubmitSaleRequest;
import com.partneros.api.dto.sale.SubmitSaleResponse;
import com.partneros.api.dto.sale.ValidateSaleRequest;
import com.partneros.api.dto.sale.ValidateSaleResponse;
import com.partneros.api.exception.PartnerOsClientException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class MoneyOrderSaleService {

    private static final Logger log = LoggerFactory.getLogger(MoneyOrderSaleService.class);

    private final PartnerOsClient client;
    private final PartnerOsAuthService authService;
    private final SalePersistenceService persistenceService;

    public MoneyOrderSaleService(
            PartnerOsClient client,
            PartnerOsAuthService authService,
            SalePersistenceService persistenceService
    ) {
        this.client = client;
        this.authService = authService;
        this.persistenceService = persistenceService;
    }

    public ValidateSaleResponse validateSale(PartnerOsRequestHeaders headers, ValidateSaleRequest request) {
        log.info("Validating money order sale externalRefId={} idempotencyKey={}",
                headers.externalRefId(), headers.idempotencyKey());
        try {
            ValidateSaleResponse response = client.validateSale(
                    authService.resolveAuthorization(headers.authorization()),
                    headers,
                    request
            );
            persistenceService.saveValidated(headers, request, response);
            log.info("Money order sale validated externalRefId={} orderId={}",
                    headers.externalRefId(), response.orderId());
            return response;
        } catch (PartnerOsClientException exception) {
            persistFailure(headers, exception);
            throw exception;
        }
    }

    public InitiateSaleResponse initiateSale(PartnerOsRequestHeaders headers, InitiateSaleRequest request) {
        log.info("Initiating money order sale externalRefId={} orderId={} idempotencyKey={}",
                headers.externalRefId(), request.order().orderId(), headers.idempotencyKey());
        try {
            InitiateSaleResponse response = client.initiateSale(
                    authService.resolveAuthorization(headers.authorization()),
                    headers,
                    request
            );
            persistenceService.saveInitiated(headers, request, response);
            log.info("Money order sale initiated externalRefId={} orderId={}",
                    headers.externalRefId(), request.order().orderId());
            return response;
        } catch (PartnerOsClientException exception) {
            persistFailure(headers, exception);
            throw exception;
        }
    }

    public SubmitSaleResponse submitSale(PartnerOsRequestHeaders headers, SubmitSaleRequest request) {
        log.info("Submitting money order sale externalRefId={} orderId={} idempotencyKey={}",
                headers.externalRefId(), request.orderId(), headers.idempotencyKey());
        try {
            SubmitSaleResponse response = client.submitSale(
                    authService.resolveAuthorization(headers.authorization()),
                    headers,
                    request
            );
            persistenceService.saveSubmitted(headers, request, response);
            log.info("Money order sale submitted externalRefId={} orderId={}",
                    headers.externalRefId(), request.orderId());
            return response;
        } catch (PartnerOsClientException exception) {
            persistFailure(headers, exception);
            throw exception;
        }
    }

    private void persistFailure(PartnerOsRequestHeaders headers, PartnerOsClientException exception) {
        log.warn("PartnerOS sale request failed externalRefId={} upstreamStatus={} upstreamCode={}",
                headers.externalRefId(), exception.getUpstreamStatus(), exception.getUpstreamCode());
        persistenceService.saveFailure(headers, exception.getUpstreamCode(), exception.getMessage());
    }
}