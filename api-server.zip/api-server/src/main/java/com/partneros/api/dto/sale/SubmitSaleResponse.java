package com.partneros.api.dto.sale;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public record SubmitSaleResponse(
        String status,
        String remainingChecks,
        String remainingDailyLimit,
        String nextBarcode,
        String terminalTime,
        Boolean ribbonPrompt,
        String totalAmount,
        String totalFee
) {
}