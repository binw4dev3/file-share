package com.partneros.api.dto.common;

public record PartnerOsRequestHeaders(
        String authorization,
        String productId,
        String externalRefId,
        String fsId,
        String channel,
        String idempotencyKey,
        String terminalId,
        String operatorId,
        String deviceId,
        String partnerOsVersion
) {
}