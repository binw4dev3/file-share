package com.partneros.api.persistence;

public enum SaleStatus {
    VALIDATED,
    INITIATED,
    SUBMITTED,
    FAILED
}