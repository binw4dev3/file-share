package com.partneros.api.service;

import com.partneros.api.dto.common.PartnerOsRequestHeaders;
import com.partneros.api.dto.sale.InitiateSaleRequest;
import com.partneros.api.dto.sale.InitiateSaleResponse;
import com.partneros.api.dto.sale.SubmitSaleRequest;
import com.partneros.api.dto.sale.SubmitSaleResponse;
import com.partneros.api.dto.sale.ValidateSaleRequest;
import com.partneros.api.dto.sale.ValidateSaleResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnProperty(
        prefix = "partneros.persistence",
        name = "enabled",
        havingValue = "false",
        matchIfMissing = true
)
public class NoOpSalePersistenceService implements SalePersistenceService {

    private static final Logger log = LoggerFactory.getLogger(NoOpSalePersistenceService.class);

    @Override
    public void saveValidated(PartnerOsRequestHeaders headers, ValidateSaleRequest request, ValidateSaleResponse response) {
        log.debug("Mongo persistence disabled; validated sale not stored externalRefId={}", headers.externalRefId());
    }

    @Override
    public void saveInitiated(PartnerOsRequestHeaders headers, InitiateSaleRequest request, InitiateSaleResponse response) {
        log.debug("Mongo persistence disabled; initiated sale not stored externalRefId={}", headers.externalRefId());
    }

    @Override
    public void saveSubmitted(PartnerOsRequestHeaders headers, SubmitSaleRequest request, SubmitSaleResponse response) {
        log.debug("Mongo persistence disabled; submitted sale not stored externalRefId={}", headers.externalRefId());
    }

    @Override
    public void saveFailure(PartnerOsRequestHeaders headers, String code, String message) {
        log.debug("Mongo persistence disabled; failed sale not stored externalRefId={}", headers.externalRefId());
    }
}