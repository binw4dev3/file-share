package com.partneros.api.dto.auth;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;

public record AuthTokenRequest(
        @JsonProperty("grant_type")
        @NotBlank
        @Schema(example = "client_credentials")
        String grantType,

        @JsonProperty("client_id")
        @NotBlank
        String clientId,

        @JsonProperty("client_secret")
        @NotBlank
        @Schema(format = "password")
        String clientSecret,

        String scope
) {
}