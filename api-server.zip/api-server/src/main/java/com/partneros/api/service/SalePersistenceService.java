package com.partneros.api.service;

import com.partneros.api.dto.common.PartnerOsRequestHeaders;
import com.partneros.api.dto.sale.InitiateSaleRequest;
import com.partneros.api.dto.sale.InitiateSaleResponse;
import com.partneros.api.dto.sale.SubmitSaleRequest;
import com.partneros.api.dto.sale.SubmitSaleResponse;
import com.partneros.api.dto.sale.ValidateSaleRequest;
import com.partneros.api.dto.sale.ValidateSaleResponse;

public interface SalePersistenceService {

    void saveValidated(
            PartnerOsRequestHeaders headers,
            ValidateSaleRequest request,
            ValidateSaleResponse response
    );

    void saveInitiated(
            PartnerOsRequestHeaders headers,
            InitiateSaleRequest request,
            InitiateSaleResponse response
    );

    void saveSubmitted(
            PartnerOsRequestHeaders headers,
            SubmitSaleRequest request,
            SubmitSaleResponse response
    );

    void saveFailure(PartnerOsRequestHeaders headers, String code, String message);
}