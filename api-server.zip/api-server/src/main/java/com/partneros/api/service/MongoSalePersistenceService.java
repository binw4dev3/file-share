package com.partneros.api.service;

import com.partneros.api.dto.common.PartnerOsRequestHeaders;
import com.partneros.api.dto.sale.InitiateSaleRequest;
import com.partneros.api.dto.sale.InitiateSaleResponse;
import com.partneros.api.dto.sale.SubmitSaleRequest;
import com.partneros.api.dto.sale.SubmitSaleResponse;
import com.partneros.api.dto.sale.ValidateSaleRequest;
import com.partneros.api.dto.sale.ValidateSaleResponse;
import com.partneros.api.exception.PersistenceException;
import com.partneros.api.persistence.MoneyOrderSaleDocument;
import com.partneros.api.persistence.MoneyOrderSaleRepository;
import com.partneros.api.persistence.SaleStatus;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import java.time.Instant;

@Service
@ConditionalOnProperty(prefix = "partneros.persistence", name = "enabled", havingValue = "true")
public class MongoSalePersistenceService implements SalePersistenceService {

    private final MoneyOrderSaleRepository repository;

    public MongoSalePersistenceService(MoneyOrderSaleRepository repository) {
        this.repository = repository;
    }

    @Override
    public void saveValidated(
            PartnerOsRequestHeaders headers,
            ValidateSaleRequest request,
            ValidateSaleResponse response
    ) {
        persist(headers, document -> {
            document.setValidateRequest(request);
            document.setValidateResponse(response);
            document.setOrderId(response.orderId());
            document.setStatus(SaleStatus.VALIDATED);
            clearError(document);
        });
    }

    @Override
    public void saveInitiated(
            PartnerOsRequestHeaders headers,
            InitiateSaleRequest request,
            InitiateSaleResponse response
    ) {
        persist(headers, document -> {
            document.setInitiateRequest(request);
            document.setInitiateResponse(response);
            document.setOrderId(request.order().orderId());
            document.setStatus(SaleStatus.INITIATED);
            clearError(document);
        });
    }

    @Override
    public void saveSubmitted(
            PartnerOsRequestHeaders headers,
            SubmitSaleRequest request,
            SubmitSaleResponse response
    ) {
        persist(headers, document -> {
            document.setSubmitRequest(request);
            document.setSubmitResponse(response);
            document.setOrderId(request.orderId());
            document.setStatus(SaleStatus.SUBMITTED);
            clearError(document);
        });
    }

    @Override
    public void saveFailure(PartnerOsRequestHeaders headers, String code, String message) {
        persist(headers, document -> {
            document.setStatus(SaleStatus.FAILED);
            document.setLastErrorCode(code);
            document.setLastErrorMessage(message);
        });
    }

    private void persist(PartnerOsRequestHeaders headers, DocumentUpdate update) {
        try {
            MoneyOrderSaleDocument document = repository
                    .findFirstByExternalRefIdOrderByUpdatedAtDesc(headers.externalRefId())
                    .orElseGet(MoneyOrderSaleDocument::new);
            Instant now = Instant.now();
            if (document.getCreatedAt() == null) {
                document.setCreatedAt(now);
            }
            document.setUpdatedAt(now);
            document.setExternalRefId(headers.externalRefId());
            document.setIdempotencyKey(headers.idempotencyKey());
            update.apply(document);
            repository.save(document);
        } catch (DataAccessException exception) {
            throw new PersistenceException("Money order sale state could not be persisted.", exception);
        }
    }

    private void clearError(MoneyOrderSaleDocument document) {
        document.setLastErrorCode(null);
        document.setLastErrorMessage(null);
    }

    @FunctionalInterface
    private interface DocumentUpdate {
        void apply(MoneyOrderSaleDocument document);
    }
}