package com.partneros.api.service;

import com.partneros.api.client.PartnerOsClient;
import com.partneros.api.config.PartnerOsProperties;
import com.partneros.api.dto.auth.AuthTokenRequest;
import com.partneros.api.dto.auth.AuthTokenResponse;
import com.partneros.api.exception.PartnerOsConfigurationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.Instant;

@Service
public class PartnerOsAuthService {

    private static final Logger log = LoggerFactory.getLogger(PartnerOsAuthService.class);

    private final PartnerOsClient client;
    private final PartnerOsProperties properties;
    private volatile CachedToken configuredCredentialToken;

    public PartnerOsAuthService(PartnerOsClient client, PartnerOsProperties properties) {
        this.client = client;
        this.properties = properties;
    }

    public AuthTokenResponse authenticate(AuthTokenRequest request) {
        log.info("Requesting PartnerOS access token for configured client match={}", isConfiguredClient(request.clientId()));
        AuthTokenResponse response = client.requestToken(request);
        if (isConfiguredClient(request.clientId())) {
            cache(response);
        }
        return response;
    }

    public String resolveAuthorization(String suppliedAuthorization) {
        if (suppliedAuthorization != null && !suppliedAuthorization.isBlank()) {
            return suppliedAuthorization.startsWith("Bearer ")
                    ? suppliedAuthorization
                    : "Bearer " + suppliedAuthorization;
        }
        return "Bearer " + getConfiguredAccessToken();
    }

    private String getConfiguredAccessToken() {
        CachedToken current = configuredCredentialToken;
        if (current != null && current.validUntil().isAfter(Instant.now())) {
            log.debug("Reusing cached PartnerOS access token");
            return current.accessToken();
        }

        synchronized (this) {
            current = configuredCredentialToken;
            if (current != null && current.validUntil().isAfter(Instant.now())) {
                return current.accessToken();
            }
            requireConfiguredCredentials();
            AuthTokenResponse response = client.requestToken(new AuthTokenRequest(
                    "client_credentials",
                    properties.getClientId(),
                    properties.getClientSecret(),
                    properties.getScope()
            ));
            cache(response);
            return response.accessToken();
        }
    }

    private void cache(AuthTokenResponse response) {
        long usableLifetime = Math.max(1, response.expiresIn() - properties.getTokenRefreshSkewSeconds());
        configuredCredentialToken = new CachedToken(
                response.accessToken(),
                Instant.now().plusSeconds(usableLifetime)
        );
        log.info("PartnerOS access token cached for {} seconds", usableLifetime);
    }

    private boolean isConfiguredClient(String clientId) {
        return clientId != null
                && properties.getClientId() != null
                && !properties.getClientId().isBlank()
                && properties.getClientId().equals(clientId);
    }

    private void requireConfiguredCredentials() {
        if (properties.getClientId() == null || properties.getClientId().isBlank()
                || properties.getClientSecret() == null || properties.getClientSecret().isBlank()) {
            throw new PartnerOsConfigurationException(
                    "Configure PARTNEROS_CLIENT_ID and PARTNEROS_CLIENT_SECRET, or supply an Authorization header."
            );
        }
    }

    private record CachedToken(String accessToken, Instant validUntil) {
    }
}