package com.partneros.api.dto.sale;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
public record SubmitSaleRequest(
        @NotBlank String orderId,
        @NotBlank String terminalId,
        String deviceId,
        @NotNull @Positive Integer totalChecks,
        String moTenderType,
        @Valid OperatorName operatorName,
        @NotNull @Valid Transaction transaction
) {
    public record OperatorName(
            @JsonAlias({"first", "firstName"}) String firstName,
            @JsonAlias({"last", "lastName"}) String lastName
    ) {
    }

    public record Transaction(@NotNull @Valid Financials financials) {
    }

    public record Financials(
            @JsonAlias({"chequeDetails", "CheckDetails", "checkDetails"})
            @NotEmpty List<@Valid CheckDetail> chequeDetails
    ) {
    }

    public record CheckDetail(
            @NotBlank String serialNumber,
            String terminalTime,
            @NotBlank String amount,
            @NotBlank String fee,
            String seqNum
    ) {
    }
}