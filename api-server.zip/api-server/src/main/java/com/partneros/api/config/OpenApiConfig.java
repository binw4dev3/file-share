package com.partneros.api.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.Operation;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.media.ObjectSchema;
import io.swagger.v3.oas.models.media.StringSchema;
import io.swagger.v3.oas.models.parameters.Parameter;
import io.swagger.v3.oas.models.parameters.RequestBody;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springdoc.core.customizers.OpenApiCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;
import java.util.Set;

@Configuration
public class OpenApiConfig {

    private static final Set<String> SALE_PATHS = Set.of(
            "/v1/pie/mosale/validate",
            "/v1/pie/mosale/initiate",
            "/v1/pie/mosale/submit"
    );

    @Bean
    public OpenAPI partnerOsOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("PartnerOS Money Orders API")
                        .version("2026-09-25")
                        .description("Backend application for Western Union PartnerOS authentication and the complete Money Order Sale Journey. "
                                + "The application validates requests, calls PartnerOS, persists lifecycle state, and returns typed responses."))
                .components(new Components()
                        .addSecuritySchemes("bearerAuth", new SecurityScheme()
                                .type(SecurityScheme.Type.HTTP)
                                .scheme("bearer")
                                .bearerFormat("OAuth 2.0 access token")));
    }

    @Bean
    public OpenApiCustomizer partnerOsContractCustomizer() {
        return openApi -> openApi.getPaths().forEach((path, pathItem) ->
                pathItem.readOperations().forEach(operation -> customize(path, operation)));
    }

    private void customize(String path, Operation operation) {
        if (path.startsWith("/actuator")) {
            return;
        }

        if (SALE_PATHS.contains(path)) {
            addHeader(operation, "x-wu-productId", "Product identifier issued during onboarding", true);
            addHeader(operation, "x-wu-externalRefId", "Unique traceable reference, max 48 characters", true);
            addHeader(operation, "x-wu-fsId", "Registered financial service identifier, max 15 alphanumeric characters", true);
            addHeader(operation, "x-wu-channel", "Partner channel; use the value registered with PartnerOS", true);
            addHeader(operation, "Idempotency-Key", "One key per business intent; required for all sale steps", true);
            addHeader(operation, "Authorization", "Optional incoming bearer token; when omitted, configured client credentials are used", false);
            addHeader(operation, "x-wu-terminalId", "Exactly 6 digits when supplied", false);
            addHeader(operation, "x-wu-operatorId", "Optional operator identifier", false);
            addHeader(operation, "x-wu-deviceId", "Optional device identifier", false);
            addHeader(operation, "PartnerOS-Version", "Optional calendar-date API version", false);
            operation.setSecurity(List.of(new SecurityRequirement().addList("bearerAuth")));
        }

        if ("/v1/partneros/auth/token".equals(path)) {
            io.swagger.v3.oas.models.media.Schema<?> formSchema = new ObjectSchema()
                    .addProperties("grant_type", new StringSchema()._default("client_credentials"))
                    .addProperties("client_id", new StringSchema())
                    .addProperties("client_secret", new StringSchema().format("password"))
                    .addProperties("scope", new StringSchema())
                    .required(List.of("grant_type", "client_id", "client_secret"));
            if (operation.getParameters() != null) {
                operation.getParameters().removeIf(parameter -> "query".equals(parameter.getIn()));
            }
            operation.setRequestBody(new RequestBody()
                    .required(true)
                    .content(new io.swagger.v3.oas.models.media.Content()
                            .addMediaType("application/x-www-form-urlencoded",
                                    new io.swagger.v3.oas.models.media.MediaType().schema(formSchema))));
            operation.setSecurity(List.of());
        }
    }

    private void addHeader(Operation operation, String name, String description, boolean required) {
        if (operation.getParameters() == null ||
                operation.getParameters().stream().noneMatch(parameter -> name.equalsIgnoreCase(parameter.getName()))) {
            operation.addParametersItem(new Parameter()
                    .in("header")
                    .name(name)
                    .description(description)
                    .required(required)
                    .schema(new StringSchema()));
        }
    }
}