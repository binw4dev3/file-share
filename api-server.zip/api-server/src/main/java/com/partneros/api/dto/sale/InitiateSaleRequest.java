package com.partneros.api.dto.sale;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@JsonInclude(JsonInclude.Include.NON_NULL)
public record InitiateSaleRequest(
        @NotNull @Valid Order order
) {
    public record Order(
            @NotBlank String orderId,
            String lifetimeDotCount,
            String currentRibbonCount,
            @NotBlank String terminalId,
            String deviceId,
            String operatorId,
            String operatorFirstName,
            String operatorLastName,
            String nextBarcode,
            String printerModel,
            String firmwareVersion,
            @Valid Purchaser purchaser
    ) {
    }

    public record Purchaser(String id) {
    }
}