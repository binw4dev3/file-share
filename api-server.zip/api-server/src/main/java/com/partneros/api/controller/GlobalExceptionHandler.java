package com.partneros.api.controller;

import com.partneros.api.config.CorrelationIdFilter;
import com.partneros.api.dto.common.ApiErrorResponse;
import com.partneros.api.exception.PartnerOsClientException;
import com.partneros.api.exception.PartnerOsConfigurationException;
import com.partneros.api.exception.PersistenceException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.ConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ApiErrorResponse> validation(
            MethodArgumentNotValidException exception,
            HttpServletRequest request
    ) {
        Map<String, String> fieldErrors = new LinkedHashMap<>();
        exception.getBindingResult().getFieldErrors().forEach(error ->
                fieldErrors.putIfAbsent(error.getField(), error.getDefaultMessage()));
        return response(HttpStatus.BAD_REQUEST, "VALIDATION_ERROR",
                "The request body failed validation.", request, null, fieldErrors);
    }

    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<ApiErrorResponse> constraintViolation(
            ConstraintViolationException exception,
            HttpServletRequest request
    ) {
        Map<String, String> fieldErrors = new LinkedHashMap<>();
        exception.getConstraintViolations().forEach(violation ->
                fieldErrors.put(violation.getPropertyPath().toString(), violation.getMessage()));
        return response(HttpStatus.BAD_REQUEST, "VALIDATION_ERROR",
                "A request parameter failed validation.", request, null, fieldErrors);
    }

    @ExceptionHandler(MissingRequestHeaderException.class)
    public ResponseEntity<ApiErrorResponse> missingHeader(
            MissingRequestHeaderException exception,
            HttpServletRequest request
    ) {
        return response(HttpStatus.BAD_REQUEST, "MISSING_HEADER",
                "Required header is missing: " + exception.getHeaderName(), request, null, Map.of());
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ApiErrorResponse> unreadableBody(
            HttpMessageNotReadableException exception,
            HttpServletRequest request
    ) {
        return response(HttpStatus.BAD_REQUEST, "INVALID_REQUEST_BODY",
                "The JSON request body is missing or malformed.", request, null, Map.of());
    }

    @ExceptionHandler(PartnerOsClientException.class)
    public ResponseEntity<ApiErrorResponse> partnerOsFailure(
            PartnerOsClientException exception,
            HttpServletRequest request
    ) {
        HttpStatus status = mapUpstreamStatus(exception.getUpstreamStatus());
        log.warn("PartnerOS request failed requestId={} upstreamStatus={} upstreamCode={}",
                requestId(), exception.getUpstreamStatus(), exception.getUpstreamCode());
        return response(status, "PARTNEROS_REQUEST_FAILED", exception.getMessage(),
                request, exception.getUpstreamCode(), Map.of());
    }

    @ExceptionHandler(PartnerOsConfigurationException.class)
    public ResponseEntity<ApiErrorResponse> configuration(
            PartnerOsConfigurationException exception,
            HttpServletRequest request
    ) {
        log.error("PartnerOS configuration error requestId={}", requestId());
        return response(HttpStatus.SERVICE_UNAVAILABLE, "PARTNEROS_CONFIGURATION_ERROR",
                exception.getMessage(), request, null, Map.of());
    }

    @ExceptionHandler(PersistenceException.class)
    public ResponseEntity<ApiErrorResponse> persistence(
            PersistenceException exception,
            HttpServletRequest request
    ) {
        log.error("Mongo persistence failed requestId={}", requestId(), exception);
        return response(HttpStatus.SERVICE_UNAVAILABLE, "PERSISTENCE_UNAVAILABLE",
                exception.getMessage(), request, null, Map.of());
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiErrorResponse> unexpected(Exception exception, HttpServletRequest request) {
        log.error("Unexpected application error requestId={}", requestId(), exception);
        return response(HttpStatus.INTERNAL_SERVER_ERROR, "INTERNAL_ERROR",
                "An unexpected error occurred.", request, null, Map.of());
    }

    private HttpStatus mapUpstreamStatus(int upstreamStatus) {
        return switch (upstreamStatus) {
            case 400, 422 -> HttpStatus.BAD_REQUEST;
            case 409 -> HttpStatus.CONFLICT;
            case 429 -> HttpStatus.TOO_MANY_REQUESTS;
            default -> HttpStatus.BAD_GATEWAY;
        };
    }

    private ResponseEntity<ApiErrorResponse> response(
            HttpStatus status,
            String code,
            String message,
            HttpServletRequest request,
            String upstreamCode,
            Map<String, String> fieldErrors
    ) {
        return ResponseEntity.status(status).body(new ApiErrorResponse(
                Instant.now(),
                status.value(),
                code,
                message,
                request.getRequestURI(),
                requestId(),
                upstreamCode,
                fieldErrors
        ));
    }

    private String requestId() {
        String requestId = MDC.get(CorrelationIdFilter.MDC_KEY);
        return requestId == null ? "" : requestId;
    }
}