package com.partneros.api.client;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.partneros.api.dto.auth.AuthTokenRequest;
import com.partneros.api.dto.auth.AuthTokenResponse;
import com.partneros.api.dto.common.PartnerOsRequestHeaders;
import com.partneros.api.dto.sale.InitiateSaleRequest;
import com.partneros.api.dto.sale.InitiateSaleResponse;
import com.partneros.api.dto.sale.SubmitSaleRequest;
import com.partneros.api.dto.sale.SubmitSaleResponse;
import com.partneros.api.dto.sale.ValidateSaleRequest;
import com.partneros.api.dto.sale.ValidateSaleResponse;
import com.partneros.api.exception.PartnerOsClientException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

@Component
public class PartnerOsClient {

    private static final String TOKEN_PATH = "/v1/partneros/auth/token";
    private static final String VALIDATE_PATH = "/v1/pie/mosale/validate";
    private static final String INITIATE_PATH = "/v1/pie/mosale/initiate";
    private static final String SUBMIT_PATH = "/v1/pie/mosale/submit";

    private final RestClient restClient;
    private final ObjectMapper objectMapper;

    public PartnerOsClient(RestClient partnerOsRestClient, ObjectMapper objectMapper) {
        this.restClient = partnerOsRestClient;
        this.objectMapper = objectMapper;
    }

    public AuthTokenResponse requestToken(AuthTokenRequest request) {
        MultiValueMap<String, String> form = new LinkedMultiValueMap<>();
        form.add("grant_type", request.grantType());
        form.add("client_id", request.clientId());
        form.add("client_secret", request.clientSecret());
        if (request.scope() != null && !request.scope().isBlank()) {
            form.add("scope", request.scope());
        }

        return exchange(
                restClient.post()
                        .uri(TOKEN_PATH)
                        .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                        .accept(MediaType.APPLICATION_JSON)
                        .body(form),
                AuthTokenResponse.class
        );
    }

    public ValidateSaleResponse validateSale(
            String authorization,
            PartnerOsRequestHeaders headers,
            ValidateSaleRequest request
    ) {
        return exchange(
                saleRequest(VALIDATE_PATH, authorization, headers).body(request),
                ValidateSaleResponse.class
        );
    }

    public InitiateSaleResponse initiateSale(
            String authorization,
            PartnerOsRequestHeaders headers,
            InitiateSaleRequest request
    ) {
        return exchange(
                saleRequest(INITIATE_PATH, authorization, headers).body(request),
                InitiateSaleResponse.class
        );
    }

    public SubmitSaleResponse submitSale(
            String authorization,
            PartnerOsRequestHeaders headers,
            SubmitSaleRequest request
    ) {
        return exchange(
                saleRequest(SUBMIT_PATH, authorization, headers).body(request),
                SubmitSaleResponse.class
        );
    }

    private RestClient.RequestBodySpec saleRequest(
            String path,
            String authorization,
            PartnerOsRequestHeaders headers
    ) {
        RestClient.RequestBodySpec request = restClient.post()
                .uri(path)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.AUTHORIZATION, authorization)
                .header("x-wu-productId", headers.productId())
                .header("x-wu-externalRefId", headers.externalRefId())
                .header("x-wu-fsId", headers.fsId())
                .header("x-wu-channel", headers.channel())
                .header("Idempotency-Key", headers.idempotencyKey());

        addOptionalHeader(request, "x-wu-terminalId", headers.terminalId());
        addOptionalHeader(request, "x-wu-operatorId", headers.operatorId());
        addOptionalHeader(request, "x-wu-deviceId", headers.deviceId());
        addOptionalHeader(request, "PartnerOS-Version", headers.partnerOsVersion());
        return request;
    }

    private void addOptionalHeader(RestClient.RequestBodySpec request, String name, String value) {
        if (value != null && !value.isBlank()) {
            request.header(name, value);
        }
    }

    private <T> T exchange(RestClient.RequestHeadersSpec<?> request, Class<T> responseType) {
        try {
            return request.exchange((outgoingRequest, incomingResponse) -> {
                byte[] responseBytes = incomingResponse.getBody().readAllBytes();
                int status = incomingResponse.getStatusCode().value();
                if (!incomingResponse.getStatusCode().is2xxSuccessful()) {
                    throw toClientException(status, responseBytes);
                }
                if (responseBytes.length == 0) {
                    return null;
                }
                try {
                    return objectMapper.readValue(responseBytes, responseType);
                } catch (IOException exception) {
                    throw new PartnerOsClientException(
                            "INVALID_UPSTREAM_RESPONSE",
                            "PartnerOS returned a response that could not be parsed.",
                            exception
                    );
                }
            });
        } catch (PartnerOsClientException exception) {
            throw exception;
        } catch (ResourceAccessException exception) {
            throw new PartnerOsClientException(
                    "UPSTREAM_UNAVAILABLE",
                    "PartnerOS could not be reached within the configured timeout.",
                    exception
            );
        } catch (RestClientException exception) {
            throw new PartnerOsClientException(
                    "UPSTREAM_REQUEST_FAILED",
                    "The PartnerOS request could not be completed.",
                    exception
            );
        }
    }

    private PartnerOsClientException toClientException(int status, byte[] responseBytes) {
        String code = "PARTNEROS_ERROR";
        String message = "PartnerOS rejected the request.";
        try {
            JsonNode error = objectMapper.readTree(responseBytes);
            code = firstText(error, code, "errorCode", "code", "name", "type");
            message = firstText(error, message, "message", "error_description", "detail");
        } catch (IOException ignored) {
            if (responseBytes.length > 0) {
                message = new String(responseBytes, StandardCharsets.UTF_8);
            }
        }
        return new PartnerOsClientException(status, code, message);
    }

    private String firstText(JsonNode node, String fallback, String... fields) {
        for (String field : fields) {
            JsonNode value = node.get(field);
            if (value != null && value.isValueNode() && !value.asText().isBlank()) {
                return value.asText();
            }
        }
        return fallback;
    }
}