package com.partneros.api.dto.sale;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public record InitiateSaleResponse(
        String result,
        String storeNumber,
        String storeName,
        String terminalId,
        Boolean labelPrinting,
        Long payExactlyItemLimitAmount,
        Boolean printVendorFromLine,
        String terminalTime,
        Integer nextCoupon,
        List<Coupon> coupons,
        List<IssuedCheck> checks
) {
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Coupon(String topLine, String middleLine, String bottomLine) {
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record IssuedCheck(
            String serialNumber,
            String fee,
            String payTo,
            String date,
            String time,
            Integer numberOfCheck,
            String status,
            String payAmount
    ) {
    }
}