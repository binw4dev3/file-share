package com.partneros.api.dto.sale;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public record ValidateSaleResponse(
        String orderId,
        String currentAgentDateTime,
        String customerUmn,
        Transaction transaction
) {
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Transaction(Financials financials) {
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Financials(
            String sendAmount,
            String orderType,
            Integer noOfChecks,
            String totalFee,
            List<CheckDetail> checkDetails
    ) {
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record CheckDetail(
            String fee,
            String amount,
            @JsonProperty("seqNum") Integer seqNum
    ) {
    }
}