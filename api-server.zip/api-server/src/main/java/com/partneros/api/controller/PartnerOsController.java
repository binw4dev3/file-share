package com.partneros.api.controller;

import com.partneros.api.dto.auth.AuthTokenRequest;
import com.partneros.api.dto.auth.AuthTokenResponse;
import com.partneros.api.dto.common.PartnerOsRequestHeaders;
import com.partneros.api.dto.sale.InitiateSaleRequest;
import com.partneros.api.dto.sale.InitiateSaleResponse;
import com.partneros.api.dto.sale.SubmitSaleRequest;
import com.partneros.api.dto.sale.SubmitSaleResponse;
import com.partneros.api.dto.sale.ValidateSaleRequest;
import com.partneros.api.dto.sale.ValidateSaleResponse;
import com.partneros.api.service.MoneyOrderSaleService;
import com.partneros.api.service.PartnerOsAuthService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirements;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Validated
@RestController
@RequestMapping
public class PartnerOsController {

    private final PartnerOsAuthService authService;
    private final MoneyOrderSaleService saleService;

    public PartnerOsController(PartnerOsAuthService authService, MoneyOrderSaleService saleService) {
        this.authService = authService;
        this.saleService = saleService;
    }

    @Operation(
            summary = "Obtain PartnerOS OAuth token",
            description = "Calls the PartnerOS OAuth 2.0 client-credentials endpoint. Configured-client tokens are cached until shortly before expiry."
    )
    @SecurityRequirements
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Access token issued"),
            @ApiResponse(responseCode = "400", description = "Invalid form values"),
            @ApiResponse(responseCode = "502", description = "PartnerOS authentication failed")
    })
    @PostMapping(
            value = "/v1/partneros/auth/token",
            consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    public AuthTokenResponse authenticate(
            @RequestParam(name = "grant_type", defaultValue = "client_credentials")
            @NotBlank String grantType,
            @RequestParam(name = "client_id")
            @NotBlank String clientId,
            @RequestParam(name = "client_secret")
            @NotBlank String clientSecret,
            @RequestParam(name = "scope", required = false)
            String scope
    ) {
        return authService.authenticate(new AuthTokenRequest(grantType, clientId, clientSecret, scope));
    }

    @Operation(
            summary = "Validate money order sale",
            description = "Validates the typed request, obtains an OAuth token when needed, invokes PartnerOS, and records the validation result."
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Sale validated"),
            @ApiResponse(responseCode = "400", description = "Request validation failed"),
            @ApiResponse(responseCode = "409", description = "PartnerOS reported a conflict"),
            @ApiResponse(responseCode = "502", description = "PartnerOS request failed")
    })
    @PostMapping(
            value = "/v1/pie/mosale/validate",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    public ValidateSaleResponse validateSale(
            @RequestBody @Valid ValidateSaleRequest request,
            @RequestHeader(name = HttpHeaders.AUTHORIZATION, required = false) String authorization,
            @RequestHeader(name = "x-wu-productId") @NotBlank String productId,
            @RequestHeader(name = "x-wu-externalRefId") @NotBlank @Size(max = 48) String externalRefId,
            @RequestHeader(name = "x-wu-fsId") @NotBlank @Size(max = 15) String fsId,
            @RequestHeader(name = "x-wu-channel") @NotBlank String channel,
            @RequestHeader(name = "Idempotency-Key") @NotBlank String idempotencyKey,
            @RequestHeader(name = "x-wu-terminalId", required = false)
            @Pattern(regexp = "^\\d{6}$", message = "must contain exactly 6 digits") String terminalId,
            @RequestHeader(name = "x-wu-operatorId", required = false) @Size(max = 20) String operatorId,
            @RequestHeader(name = "x-wu-deviceId", required = false) String deviceId,
            @RequestHeader(name = "PartnerOS-Version", required = false) String partnerOsVersion
    ) {
        return saleService.validateSale(headers(
                authorization, productId, externalRefId, fsId, channel, idempotencyKey,
                terminalId, operatorId, deviceId, partnerOsVersion
        ), request);
    }

    @Operation(
            summary = "Initiate money order sale",
            description = "Initiates a previously validated sale and records printer/check information returned by PartnerOS."
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Sale initiated"),
            @ApiResponse(responseCode = "400", description = "Request validation failed"),
            @ApiResponse(responseCode = "409", description = "PartnerOS reported a conflict"),
            @ApiResponse(responseCode = "502", description = "PartnerOS request failed")
    })
    @PostMapping(
            value = "/v1/pie/mosale/initiate",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    public InitiateSaleResponse initiateSale(
            @RequestBody @Valid InitiateSaleRequest request,
            @RequestHeader(name = HttpHeaders.AUTHORIZATION, required = false) String authorization,
            @RequestHeader(name = "x-wu-productId") @NotBlank String productId,
            @RequestHeader(name = "x-wu-externalRefId") @NotBlank @Size(max = 48) String externalRefId,
            @RequestHeader(name = "x-wu-fsId") @NotBlank @Size(max = 15) String fsId,
            @RequestHeader(name = "x-wu-channel") @NotBlank String channel,
            @RequestHeader(name = "Idempotency-Key") @NotBlank String idempotencyKey,
            @RequestHeader(name = "x-wu-terminalId", required = false)
            @Pattern(regexp = "^\\d{6}$", message = "must contain exactly 6 digits") String terminalId,
            @RequestHeader(name = "x-wu-operatorId", required = false) @Size(max = 20) String operatorId,
            @RequestHeader(name = "x-wu-deviceId", required = false) String deviceId,
            @RequestHeader(name = "PartnerOS-Version", required = false) String partnerOsVersion
    ) {
        return saleService.initiateSale(headers(
                authorization, productId, externalRefId, fsId, channel, idempotencyKey,
                terminalId, operatorId, deviceId, partnerOsVersion
        ), request);
    }

    @Operation(
            summary = "Submit money order sale",
            description = "Completes a previously initiated sale and records the final PartnerOS response."
    )
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Sale submitted"),
            @ApiResponse(responseCode = "400", description = "Request validation failed"),
            @ApiResponse(responseCode = "409", description = "PartnerOS reported a conflict"),
            @ApiResponse(responseCode = "502", description = "PartnerOS request failed")
    })
    @PostMapping(
            value = "/v1/pie/mosale/submit",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    public SubmitSaleResponse submitSale(
            @RequestBody @Valid SubmitSaleRequest request,
            @RequestHeader(name = HttpHeaders.AUTHORIZATION, required = false) String authorization,
            @RequestHeader(name = "x-wu-productId") @NotBlank String productId,
            @RequestHeader(name = "x-wu-externalRefId") @NotBlank @Size(max = 48) String externalRefId,
            @RequestHeader(name = "x-wu-fsId") @NotBlank @Size(max = 15) String fsId,
            @RequestHeader(name = "x-wu-channel") @NotBlank String channel,
            @RequestHeader(name = "Idempotency-Key") @NotBlank String idempotencyKey,
            @RequestHeader(name = "x-wu-terminalId", required = false)
            @Pattern(regexp = "^\\d{6}$", message = "must contain exactly 6 digits") String terminalId,
            @RequestHeader(name = "x-wu-operatorId", required = false) @Size(max = 20) String operatorId,
            @RequestHeader(name = "x-wu-deviceId", required = false) String deviceId,
            @RequestHeader(name = "PartnerOS-Version", required = false) String partnerOsVersion
    ) {
        return saleService.submitSale(headers(
                authorization, productId, externalRefId, fsId, channel, idempotencyKey,
                terminalId, operatorId, deviceId, partnerOsVersion
        ), request);
    }

    private PartnerOsRequestHeaders headers(
            String authorization,
            String productId,
            String externalRefId,
            String fsId,
            String channel,
            String idempotencyKey,
            String terminalId,
            String operatorId,
            String deviceId,
            String partnerOsVersion
    ) {
        return new PartnerOsRequestHeaders(
                authorization,
                productId,
                externalRefId,
                fsId,
                channel,
                idempotencyKey,
                terminalId,
                operatorId,
                deviceId,
                partnerOsVersion
        );
    }
}