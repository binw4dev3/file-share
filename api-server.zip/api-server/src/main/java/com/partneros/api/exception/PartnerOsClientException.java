package com.partneros.api.exception;

public class PartnerOsClientException extends RuntimeException {

    private final int upstreamStatus;
    private final String upstreamCode;

    public PartnerOsClientException(int upstreamStatus, String upstreamCode, String message) {
        super(message);
        this.upstreamStatus = upstreamStatus;
        this.upstreamCode = upstreamCode;
    }

    public PartnerOsClientException(String code, String message, Throwable cause) {
        super(message, cause);
        this.upstreamStatus = 502;
        this.upstreamCode = code;
    }

    public int getUpstreamStatus() {
        return upstreamStatus;
    }

    public String getUpstreamCode() {
        return upstreamCode;
    }
}