package com.partneros.api.persistence;

import com.partneros.api.dto.sale.InitiateSaleRequest;
import com.partneros.api.dto.sale.InitiateSaleResponse;
import com.partneros.api.dto.sale.SubmitSaleRequest;
import com.partneros.api.dto.sale.SubmitSaleResponse;
import com.partneros.api.dto.sale.ValidateSaleRequest;
import com.partneros.api.dto.sale.ValidateSaleResponse;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;

@Document("money_order_sales")
public class MoneyOrderSaleDocument {

    @Id
    private String id;

    @Indexed
    private String externalRefId;

    @Indexed
    private String orderId;

    private String idempotencyKey;
    private SaleStatus status;
    private ValidateSaleRequest validateRequest;
    private ValidateSaleResponse validateResponse;
    private InitiateSaleRequest initiateRequest;
    private InitiateSaleResponse initiateResponse;
    private SubmitSaleRequest submitRequest;
    private SubmitSaleResponse submitResponse;
    private String lastErrorCode;
    private String lastErrorMessage;
    private Instant createdAt;
    private Instant updatedAt;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getExternalRefId() {
        return externalRefId;
    }

    public void setExternalRefId(String externalRefId) {
        this.externalRefId = externalRefId;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getIdempotencyKey() {
        return idempotencyKey;
    }

    public void setIdempotencyKey(String idempotencyKey) {
        this.idempotencyKey = idempotencyKey;
    }

    public SaleStatus getStatus() {
        return status;
    }

    public void setStatus(SaleStatus status) {
        this.status = status;
    }

    public ValidateSaleRequest getValidateRequest() {
        return validateRequest;
    }

    public void setValidateRequest(ValidateSaleRequest validateRequest) {
        this.validateRequest = validateRequest;
    }

    public ValidateSaleResponse getValidateResponse() {
        return validateResponse;
    }

    public void setValidateResponse(ValidateSaleResponse validateResponse) {
        this.validateResponse = validateResponse;
    }

    public InitiateSaleRequest getInitiateRequest() {
        return initiateRequest;
    }

    public void setInitiateRequest(InitiateSaleRequest initiateRequest) {
        this.initiateRequest = initiateRequest;
    }

    public InitiateSaleResponse getInitiateResponse() {
        return initiateResponse;
    }

    public void setInitiateResponse(InitiateSaleResponse initiateResponse) {
        this.initiateResponse = initiateResponse;
    }

    public SubmitSaleRequest getSubmitRequest() {
        return submitRequest;
    }

    public void setSubmitRequest(SubmitSaleRequest submitRequest) {
        this.submitRequest = submitRequest;
    }

    public SubmitSaleResponse getSubmitResponse() {
        return submitResponse;
    }

    public void setSubmitResponse(SubmitSaleResponse submitResponse) {
        this.submitResponse = submitResponse;
    }

    public String getLastErrorCode() {
        return lastErrorCode;
    }

    public void setLastErrorCode(String lastErrorCode) {
        this.lastErrorCode = lastErrorCode;
    }

    public String getLastErrorMessage() {
        return lastErrorMessage;
    }

    public void setLastErrorMessage(String lastErrorMessage) {
        this.lastErrorMessage = lastErrorMessage;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Instant updatedAt) {
        this.updatedAt = updatedAt;
    }
}