# PartnerOS Money Orders Backend

Spring Boot backend implementing Western Union PartnerOS authentication and the
Money Order Sale Journey.

This is not a transparent proxy. Incoming requests are bound to validated DTOs,
processed by application services, sent through a typed PartnerOS client, and
optionally persisted as a MongoDB sale lifecycle document.

## Architecture

```text
PartnerOsController
    ├── PartnerOsAuthService
    │       └── PartnerOsClient
    └── MoneyOrderSaleService
            ├── PartnerOsAuthService
            ├── PartnerOsClient
            └── SalePersistenceService
                    ├── MongoSalePersistenceService
                    └── NoOpSalePersistenceService
```

The Mongo document records validation, initiation, submission, status,
timestamps, order ID, external reference, idempotency key, and the last
PartnerOS error. OAuth tokens and credentials are never persisted.

## Endpoints

| Method | Local endpoint | PartnerOS operation |
|---|---|---|
| POST | `/api/v1/partneros/auth/token` | OAuth client credentials |
| POST | `/api/v1/pie/mosale/validate` | Validate sale |
| POST | `/api/v1/pie/mosale/initiate` | Initiate sale |
| POST | `/api/v1/pie/mosale/submit` | Submit sale |

Swagger UI is available at `/api/swagger-ui/index.html`.

## Authentication behavior

The token endpoint accepts `application/x-www-form-urlencoded`:

```text
grant_type=client_credentials
client_id=...
client_secret=...
scope=...
```

Sale endpoints can receive an `Authorization: Bearer ...` header. When it is
omitted, the service obtains and caches a token using
`PARTNEROS_CLIENT_ID` and `PARTNEROS_CLIENT_SECRET`.

## Required sale headers

- `x-wu-productId`
- `x-wu-externalRefId`
- `x-wu-fsId`
- `x-wu-channel`
- `Idempotency-Key`

Optional PartnerOS headers are explicitly supported in the controller and
client; arbitrary incoming headers are not forwarded.

## Configuration

| Variable | Default | Purpose |
|---|---|---|
| `PARTNEROS_UPSTREAM_BASE_URL` | `http://localhost:8082` | PartnerOS environment |
| `PARTNEROS_CLIENT_ID` | empty | OAuth client ID used by sale services |
| `PARTNEROS_CLIENT_SECRET` | empty | OAuth client secret used by sale services |
| `PARTNEROS_SCOPE` | empty | Optional OAuth scope |
| `PARTNEROS_CONNECT_TIMEOUT_MS` | `5000` | Upstream connection timeout |
| `PARTNEROS_READ_TIMEOUT_MS` | `10000` | Upstream response timeout |
| `MONGODB_ENABLED` | `false` | Enables Mongo lifecycle persistence |
| `MONGODB_URI` | `mongodb://localhost:27017/partneros` | MongoDB connection URI |

Keep credentials and Mongo connection strings in Replit Secrets.

## Error responses

All application errors use one envelope:

```json
{
  "timestamp": "2026-09-23T22:30:00Z",
  "status": 400,
  "code": "VALIDATION_ERROR",
  "message": "The request body failed validation.",
  "path": "/api/v1/pie/mosale/validate",
  "requestId": "d18a892b-0d55-4e03-8e36-18d67720c169",
  "fieldErrors": {
    "transaction.financials.sendAmount": "must not be blank"
  }
}
```

Every response receives `X-Request-Id`. Logs include request IDs, external
references, order IDs, and idempotency keys, but not credentials, access tokens,
or customer request bodies.

## Build and test

```bash
mvn clean test
mvn -DskipTests package
mvn spring-boot:run
```

Health is available at `/api/actuator/health`.